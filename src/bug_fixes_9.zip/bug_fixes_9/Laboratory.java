package bug_fixes_9;

import battlecode.common.*;

public class Laboratory {
	public static RobotController rc;

	
	public static void update() throws GameActionException {
	}
	
	public static void act() throws GameActionException {
	}

}
