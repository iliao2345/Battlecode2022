package speed_health_trading_9;

import battlecode.common.*;

public class Watchtower {
	public static RobotController rc;

	
	public static void update() throws GameActionException {
	}
	
	public static void act() throws GameActionException {
	}

}
